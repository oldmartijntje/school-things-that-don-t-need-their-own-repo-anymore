antwoord1 = input("is de kaas geel? >>>")
if antwoord1 == "ja":
    antwoord2 = input("zitten er gaten in? >>>")
    if antwoord2 == "ja":
        antwoord3 = input("is de kaas belachelijk duur? >>>")
        if antwoord3 =="ja":
            print("het is emmenthaler")
        else:
            print("het is leerdammer")
    else:
        antwoord4 = input("is de kaas hard als steen? >>>")
        if antwoord4 =="ja":
            print("het is pemnigiano reggiano")
        else:
            print("het is goudse kaas")
else:
    antwoord5 = input("heeft de kaas blauwe schimmels? >>>")
    if antwoord5 =="ja":
        antwoord6 = input("heeft de kaas een korst? >>>")
        if antwoord6 =="ja":
            print("het is bleu de rochbaron")
        else:
            print("faume d'ambert")
    else:
        antwoord6 = input("heeft de kaas een korst? >>>")
        if antwoord6 =="ja":
            print("camembert")
        else:
            print("mozzarella")

        
    
    
        
